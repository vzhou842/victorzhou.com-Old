Contact:
vzhou842@gmail.com
(214) 843-5978


Website:
www.victorzhou.com


iTunes Link:
https://itunes.apple.com/us/app/moby-dick-the-game/id803997829?mt=8&uo=4


Description:
Moby Dick: The Game, based on Herman Melville's masterpiece Moby Dick, is an engaging adventure for all. Play as the White Whale, smash ships, explore the seas, and upgrade yourself! 

Features:
     -Over 10 ships, 17 stages, 3 boss fights, and 8 upgrades.
     -Game Center integration: compare yourself to players worldwide!
     -Realistic physics collisions, particles, and trajectories.