Flooding Dots Press Kit


The sequel to Falling Dots, Flooding Dots brings a unique twist to the classic dot-tapping game. Experience all-new effects on Black, Green, Purple, Blue and Red Dots, along with powerups, items, and combos! Race against the clock in Singleplayer mode or play against online players in Multiplayer. Can you handle the Dots? 

Features:
   -Singleplayer Mode
   -Multiplayer Mode: play online against friends/strangers
   -Dot Shop: 6 skins and 3 items
   -5 types of dots
   -3 types of power-ups
   -18 challenges to master
   -5 skills to upgrade
   -Global Leaderboards through Game Center



Made by Victor Zhou.
vzhou842@gmail.com
www.victorzhou.com
Promo Video: https://www.youtube.com/watch?v=WBUVF3bVwuE
